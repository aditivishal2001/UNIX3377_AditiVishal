# Starting with Git

-------

### Git-test-repo
This is the repo we'll use in our Pull Request discussion.  Enjoy!!


git remote add origin https://github.com/AlohaCode/Starting-with-Git-and-GitHub.git
git push -u origin master


